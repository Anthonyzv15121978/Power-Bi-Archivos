# The World of Peaches 🍑🏆

**Winner of the Power BI World Championship 2026** (FabCon, Atlanta, March 2026).

This is the official, original report file I built for the championship. After months of requests, it is now public: the full working report, the extracted source code, every DAX pattern, and the curated HTML components, all in one place for you to study and reuse.

![The World of Peaches · Overview](docs/screenshots/overview.png)

## Download

Grab **[The World of Peaches (World Champs 26).pbix](The%20World%20of%20Peaches%20(World%20Champs%2026).pbix)** and open it in Power BI Desktop. Everything ships inside: model, data, theme, components, bookmarks and the embedded tutorial.

## What is inside

| Area | What you will find |
|---|---|
| `dax/` | All 45 measures as standalone `.dax` files, commented and organised per page. Dynamic layers driven by field parameters, SVG buttons authored in DAX, waffle charts, KPI towers, alt-text measures for accessibility |
| `html-components/` | 17 curated HTML component templates extracted from the report, with their CSS split into `html-components/css/`. Each component is refined and fitted to its container so you can adapt it to your own projects. `<!--{DAX}-->` marks where the report injects dynamic values |
| `src/Model/` | The complete semantic model in TMDL: tables, relationships, calendar, field parameters and the `_Measures` table |
| `src/Report/` | Report layout, bookmarks (tutorial flow, close states) and section definitions |
| `src/StaticResources/` | The theme file. The theme JSON carries far more than colours: button presets, visual styles and design tokens are all set at theme level so visuals inherit the design instead of being formatted one by one |

## The approach, in short

The dashboard was designed before Power BI opened. Design tokens live twice, once in CSS and once in the theme JSON, so every component and every native visual reads from the same source of truth. Components were built and refined in isolation, then fitted to their containers. The model answers the wireframe: calendar as a relationship, folders as questions, field parameters driving the dynamic layer instead of bookmark sprawl.

If you want the full story behind each decision, I wrote a six episode breakdown, available in the members area at [gusbavia.com](https://www.gusbavia.com)

## Data

Production and trade figures come from [FAOSTAT](https://www.fao.org/faostat/) (2024 release, public domain). The report was built against the two CSV extracts referenced in the M queries; repoint the two sources in Power Query if you want to refresh.

Images and video loops are served from a public CDN and load automatically.

## Reusing the components

1. Open any template in `html-components/` next to its stylesheet in `html-components/css/`
2. Replace each `<!--{DAX}-->` marker with your own value, colour token or measure output
3. In Power BI, feed the assembled string to an HTML rendering visual sized to the same container proportions

The originals in `src/Model/tables/_Measures.tmdl` show the full working DAX that assembles each component dynamically.

## Licence

MIT. Use it, learn from it, ship your own version. A mention is appreciated but not required.

---

**Gus Bavia** · [gusbavia.com](https://www.gusbavia.com) · [LinkedIn](https://www.linkedin.com/in/gusbavia)
*Power BI World Champion 2026 · FabCon Atlanta*
